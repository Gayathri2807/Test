package com.example.Assignment.Service;

public interface StoreList {

    public void getAvailabilityList();
    public void getCapacityList();
}
