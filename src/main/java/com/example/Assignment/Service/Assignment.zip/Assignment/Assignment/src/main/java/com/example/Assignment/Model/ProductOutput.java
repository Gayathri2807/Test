package com.example.Assignment.Model;

import lombok.Data;

import java.util.List;


@Data
public class ProductOutput {
    private List<Product> productOutput;
}
